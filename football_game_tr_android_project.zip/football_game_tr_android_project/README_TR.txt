FOOTBALL GAME TR — Android Studio proje başlangıcı

Bu paket APK DEĞİLDİR; Android Studio ile APK derlemek için hazırlanmış kaynak projedir.

Derleme:
1) Bilgisayara Android Studio ve Android SDK kur.
2) Android Studio > Open ile bu klasörü aç.
3) Gradle senkronizasyonunun bitmesini bekle.
4) Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
5) APK, app/build/outputs/apk/debug/app-debug.apk konumunda oluşur.

Notlar:
- Uygulama yatay ekran ve tam ekran olarak ayarlanmıştır.
- Oyun arayüzü assets/index.html dosyasından yüklenir.
- Bu proje bu ortamda Android SDK bulunmadığı için derlenip cihazda test edilmemiştir.
